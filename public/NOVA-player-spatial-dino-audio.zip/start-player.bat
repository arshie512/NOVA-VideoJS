@echo off
setlocal
cd /d "%~dp0"
node "%~dp0serve-player.mjs"
